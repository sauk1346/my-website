export default function About() {
    return(
        <>
            <h1>About</h1>
            <p>...en construcción</p>
        </>
    )
}