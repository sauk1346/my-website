
export default function Bootcamps() {
    return(
        <>
            <h1>Bootcamps</h1>
            <p>...en construcción</p>
        </>
    )
}