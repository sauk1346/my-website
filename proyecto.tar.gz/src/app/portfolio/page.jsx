
export default function Portfolio() {
    return(
        <>
            <h1>Portfolio</h1>
            <p>...en construcción</p>
        </>
    )
}